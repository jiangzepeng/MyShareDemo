package com.jzp.mysharedemo;

import com.umeng.socialize.media.WBShareCallBackActivity;

/**
 * 在application里配置主要参数
 * Created by jzp on 16/05/3.
 */
public class WBShareActivity extends WBShareCallBackActivity
{
}
